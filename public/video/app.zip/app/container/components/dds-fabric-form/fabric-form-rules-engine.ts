import type { FabricFormSection } from '../../models/fabric-form.model';

type RuleOperator = 'eq';
type RuleAction = 'show' | 'hide';

interface FieldRuleCondition {
  field: string;
  op: RuleOperator;
  value: unknown;
}

interface FieldRuleThen {
  action: RuleAction;
  target?: {
    fields?: string[];
  };
}

interface FieldRule {
  when?: FieldRuleCondition;
  then?: FieldRuleThen[];
}

interface ControlRule {
  sourceControl: string;
  condition: FieldRuleCondition;
  actions: Array<{ action: RuleAction; targetControl: string }>;
}

/**
 * Minimal rules engine for dds-fabric-form.
 * Supports: when.field + op:eq + then.action(show/hide) on target.fields.
 */
export class FabricFormRulesEngine {
  private compiledRules: ControlRule[] = [];
  private useFieldIdOnly = false;

  init(sections: FabricFormSection[], options?: { useFieldIdOnly?: boolean }): void {
    this.useFieldIdOnly = !!options?.useFieldIdOnly;
    this.compiledRules = [];
    sections.forEach((section) => {
      (section.formFieldConfig ?? []).forEach((field) => {
        const sourceControl = this.controlName(section.sectionID, field.fieldID);
        const rawRules = (field as { rules?: FieldRule[] }).rules ?? [];
        rawRules.forEach((rule) => {
          if (!rule?.when || !Array.isArray(rule.then)) return;
          const actions = rule.then
            .flatMap((thenItem) =>
              (thenItem?.target?.fields ?? []).map((targetFieldId) => ({
                action: thenItem.action,
                targetControl: this.controlName(section.sectionID, targetFieldId),
              }))
            )
            .filter((a) => a.action === 'show' || a.action === 'hide');
          if (actions.length) {
            this.compiledRules.push({
              sourceControl,
              condition: rule.when,
              actions,
            });
          }
        });
      });
    });
  }

  evaluate(
    rawValue: Record<string, unknown>,
    sections: FabricFormSection[]
  ): Map<string, boolean> {
    const visibility = new Map<string, boolean>();

    // Default visibility from hideOnLoad
    sections.forEach((section) => {
      (section.formFieldConfig ?? []).forEach((field) => {
        visibility.set(this.controlName(section.sectionID, field.fieldID), !field.hideOnLoad);
      });
    });

    // Apply rules
    this.compiledRules.forEach((rule) => {
      const whenFieldControl = this.resolveWhenControl(rule.sourceControl, rule.condition.field);
      const currentValue = rawValue[whenFieldControl];
      if (!this.matches(currentValue, rule.condition)) return;
      rule.actions.forEach((action) => {
        visibility.set(action.targetControl, action.action === 'show');
      });
    });

    return visibility;
  }

  private resolveWhenControl(sourceControl: string, fieldRef: string): string {
    if (fieldRef.includes('.')) {
      const [group, field] = fieldRef.split('.');
      return this.controlName(group, field);
    }
    const [group] = sourceControl.split('__');
    return this.controlName(group, fieldRef);
  }

  private matches(value: unknown, condition: FieldRuleCondition): boolean {
    if (condition.op === 'eq') {
      return String(value ?? '') === String(condition.value ?? '');
    }
    return false;
  }

  private controlName(sectionId: string, fieldId: string): string {
    return this.useFieldIdOnly ? fieldId : `${sectionId}__${fieldId}`;
  }
}
