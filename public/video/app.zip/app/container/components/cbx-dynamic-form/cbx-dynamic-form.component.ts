import { Component, EventEmitter, Input, Output } from '@angular/core';
import type { FabricFormMetaInput, FabricFormOption } from '../../models/fabric-form.model';

/**
 * Common shell for JSON-driven forms: passes `formMetaData` + `dropdownData` into `dds-fabric-form`.
 * Projected content (`ng-content`) can hold future custom templates (IGTB parity).
 */
@Component({
  selector: 'cbx-dynamic-form',
  templateUrl: './cbx-dynamic-form.component.html',
  styleUrls: ['./cbx-dynamic-form.component.scss'],
})
export class CbxDynamicFormComponent {
  @Input() formMetaData: FabricFormMetaInput = null;
  @Input() dropdownData: Record<string, FabricFormOption[]> = {};
  @Input() editMode = false;
  @Input() editPatch: Record<string, unknown> | null = null;
  /** Passes through to `dds-fabric-form`: payload keys use `fieldID` only (e.g. `name`). */
  @Input() useFieldIdOnly = false;

  /** IGTB parity — optional stubs (ignored by Midas dds-fabric-form stub). */
  @Input() submitSource: unknown;
  @Input() templateSource: unknown;
  @Input() editSource: unknown;
  @Input() formUpdateConfigService: unknown;
  @Input() formLoaderService: unknown;
  @Input() locales: unknown;
  @Input() fileUploadActionService: unknown;
  @Input() subformValidator: unknown;
  @Input() asyncValidationService: unknown;
  @Input() customValidatorService: unknown;
  @Input() templateValidtorService: unknown;
  @Input() fileUploadValidateService: unknown;
  @Input() customControlMapper: unknown;
  @Input() gridActionEvent: unknown;
  @Input() formButtonAppearanceEvent: unknown;

  @Output() actionListnerEvent = new EventEmitter<Record<string, unknown>>();
  @Output() formCancelConfirmEvent = new EventEmitter<void>();
  @Output() subTextLinkClick = new EventEmitter<unknown>();
  @Output() onFormActionBtnClick = new EventEmitter<unknown>();
  @Output() onGridActionBtnClick = new EventEmitter<unknown>();
  @Output() onRecordsAdd = new EventEmitter<unknown>();
  @Output() recordsGroupChange = new EventEmitter<unknown>();
  @Output() onSaveAsTemplateBtnClick = new EventEmitter<void>();
}
