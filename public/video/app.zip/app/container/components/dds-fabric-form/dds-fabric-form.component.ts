import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import type {
  FabricFormField,
  FabricFormMeta,
  FabricFormMetaInput,
  FabricFormOption,
  FabricFormSection,
} from '../../models/fabric-form.model';
import { FabricFormRulesEngine } from './fabric-form-rules-engine';

/**
 * Midas-local stand-in for IGTB dds-fabric-form. Replace when @igtb-digital packages are added.
 */
@Component({
  selector: 'dds-fabric-form',
  templateUrl: './dds-fabric-form.component.html',
  styleUrls: ['./dds-fabric-form.component.scss'],
})
export class DdsFabricFormComponent implements OnChanges, OnDestroy {
  /**
   * Must be `{ formConfig?, formSectionConfig }` from JSON **or** the `formSectionConfig` array only.
   * If you assign the array by mistake, `formSectionConfig` is missing → `sections` stays empty → nothing renders.
   */
  @Input() formMetaData: FabricFormMetaInput = null;
  @Input() dropdownData: Record<string, FabricFormOption[]> = {};
  @Input() editMode = false;
  @Input() editPatch: Record<string, unknown> | null = null;
  /** When true, control names and emitted payload keys are `fieldID` only (e.g. `name`), not `sectionID__fieldID`. */
  @Input() useFieldIdOnly = false;

  @Input() submitSource: unknown;
  @Input() templateSource: unknown;
  @Input() formUpdateConfigService: unknown;
  @Input() formLoaderService: unknown;
  @Input() locales: unknown;
  @Input() fileUploadActionService: unknown;
  @Input() subformValidator: unknown;
  @Input() asyncValidationService: unknown;
  @Input() customValidatorService: unknown;
  @Input() templateValidtorService: unknown;
  @Input() fileUploadValidateService: unknown;
  @Input() customControlMapper: unknown;
  @Input() gridActionEvent: unknown;
  @Input() formButtonAppearanceEvent: unknown;
  @Input() editSource: unknown;

  @Output() actionListnerEvent = new EventEmitter<Record<string, unknown>>();
  @Output() formCancelConfirmEvent = new EventEmitter<void>();
  @Output() subTextLinkClick = new EventEmitter<unknown>();

  form: FormGroup = this.fb.group({});
  sections: FabricFormSection[] = [];
  private rulesEngine = new FabricFormRulesEngine();
  private ruleVisibility = new Map<string, boolean>();
  private formValueSub?: Subscription;
  buttonLabels = {
    submitCreate: 'Save',
    submitUpdate: 'Update',
    cancel: 'Cancel',
  };

  constructor(private fb: FormBuilder, private cdr: ChangeDetectorRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['formMetaData'] || changes['dropdownData'] || changes['useFieldIdOnly']) {
      this.syncFromMeta();
    }
    if (changes['editPatch'] && this.editPatch && this.form) {
      this.applyPatch(this.editPatch);
    }
    if (changes['formMetaData'] && this.formMetaData && this.editPatch) {
      this.applyPatch(this.editPatch);
    }
  }

  /**
   * Accepts full `DynamicFormConfig`-style object or a bare `formSectionConfig` array (common mistake when debugging).
   */
  private toFabricFormMeta(raw: FabricFormMetaInput): FabricFormMeta | null {
    if (raw == null) {
      return null;
    }
    if (Array.isArray(raw)) {
      return { formSectionConfig: raw };
    }
    return raw;
  }

  private syncFromMeta(): void {
    const meta = this.toFabricFormMeta(this.formMetaData);
    if (!meta) {
      this.sections = [];
      this.form = this.fb.group({});
      this.formValueSub?.unsubscribe();
      this.cdr.detectChanges();
      return;
    }
    const fc = meta.formConfig ?? {};
    this.buttonLabels = {
      submitCreate: (fc.submitCreateLabel as string) || this.buttonLabels.submitCreate,
      submitUpdate: (fc.submitUpdateLabel as string) || this.buttonLabels.submitUpdate,
      cancel: (fc.cancelLabel as string) || this.buttonLabels.cancel,
    };
    this.sections = Array.isArray(meta.formSectionConfig)
      ? meta.formSectionConfig.filter((s) => !s.hideOnLoad)
      : [];
    this.buildForm();
    this.initRules();
    if (this.editPatch) {
      this.applyPatch(this.editPatch);
    }
    this.evaluateRules();
    this.cdr.detectChanges();
  }

  private buildForm(): void {
    const controls: Record<string, ReturnType<FormBuilder['control']>> = {};
    this.sections.forEach((section) => {
      const fields = section.formFieldConfig;
      if (!Array.isArray(fields)) {
        return;
      }
      fields.forEach((field) => {
        if (!field?.fieldID || !field.controlType) {
          return;
        }
        const name = this.getControlName(section.sectionID, field.fieldID);
        const validators = this.toValidators(field);
        controls[name] = this.fb.control(this.getInitialValue(field), validators);
      });
    });
    this.form = this.fb.group(controls);
  }

  private initRules(): void {
    this.rulesEngine.init(this.sections, { useFieldIdOnly: this.useFieldIdOnly });
    this.formValueSub?.unsubscribe();
    this.formValueSub = this.form.valueChanges.subscribe(() => {
      this.evaluateRules();
    });
  }

  private evaluateRules(): void {
    this.ruleVisibility = this.rulesEngine.evaluate(
      this.form.getRawValue() as Record<string, unknown>,
      this.sections
    );
    this.cdr.detectChanges();
  }

  private applyPatch(flat: Record<string, unknown>): void {
    Object.keys(flat).forEach((key) => {
      const c = this.form.get(key);
      if (c) {
        c.patchValue(flat[key] as never, { emitEvent: false });
      }
    });
    this.cdr.detectChanges();
  }

  private getInitialValue(field: FabricFormField): string | boolean | string[] | null {
    if (field.controlType === 'Dropdown' && field.multiple) {
      return [];
    }
    if (field.value !== undefined && field.value !== null) {
      if (typeof field.value === 'string' || typeof field.value === 'boolean') {
        return field.value;
      }
      const valueObj = field.value as { id?: string; value?: string };
      if (typeof valueObj?.id === 'string') {
        return valueObj.id;
      }
      if (typeof valueObj?.value === 'string') {
        return valueObj.value;
      }
    }
    return field.controlType === 'Checkbox' ? false : '';
  }

  private normalizeOptions(options: Array<string | FabricFormOption> | undefined): FabricFormOption[] {
    if (!options?.length) {
      return [];
    }
    return options.map((item) =>
      typeof item === 'string' ? { label: item, value: item } : { label: item.label, value: item.value }
    );
  }

  getControlName(sectionId: string, fieldId: string): string {
    return this.useFieldIdOnly ? fieldId : `${sectionId}__${fieldId}`;
  }

  getVisibleFields(section: FabricFormSection): FabricFormField[] {
    return (section.formFieldConfig ?? []).filter(
      (f) => f && this.isFieldVisible(section.sectionID, f)
    );
  }

  isFieldVisible(sectionId: string, field: FabricFormField): boolean {
    const key = this.getControlName(sectionId, field.fieldID);
    if (this.ruleVisibility.has(key)) {
      return !!this.ruleVisibility.get(key);
    }
    return !field.hideOnLoad;
  }

  fieldLabel(field: FabricFormField): string {
    return field.fieldLabel || field.ariaLabel || field.fieldID;
  }

  getOptions(field: FabricFormField): FabricFormOption[] {
    if (field.options && Array.isArray(field.options) && field.options.length) {
      return this.normalizeOptions(field.options);
    }
    if (field.dataSourceKey && this.dropdownData[field.dataSourceKey]?.length) {
      return this.dropdownData[field.dataSourceKey];
    }
    if (this.dropdownData[field.fieldID]?.length) {
      return this.dropdownData[field.fieldID];
    }
    return [];
  }

  private toValidators(field: FabricFormField): ValidatorFn[] {
    const validators: ValidatorFn[] = [];
    if (field.mandatory) {
      validators.push(Validators.required);
    }

    (field.validators ?? []).forEach((v) => {
      if (v?.validatorName?.toLowerCase() === 'regex' && v.validatorValue) {
        validators.push(Validators.pattern(v.validatorValue));
      }
    });

    return validators;
  }

  isRadioChecked(sectionId: string, fieldId: string, optionValue: string): boolean {
    const control = this.form.get(this.getControlName(sectionId, fieldId));
    return String(control?.value ?? '') === String(optionValue);
  }

  onRadioChange(sectionId: string, fieldId: string, optionValue: string): void {
    const control = this.form.get(this.getControlName(sectionId, fieldId));
    if (!control) return;
    control.setValue(optionValue);
    control.markAsDirty();
    control.markAsTouched();
    this.evaluateRules();
  }

  hasRequiredError(sectionId: string, fieldId: string): boolean {
    const c = this.form.get(this.getControlName(sectionId, fieldId));
    return !!(c?.touched && c?.hasError('required'));
  }

  hasPatternError(sectionId: string, fieldId: string): boolean {
    const c = this.form.get(this.getControlName(sectionId, fieldId));
    return !!(c?.touched && c?.hasError('pattern'));
  }

  formTitle(): string {
    const m = this.toFabricFormMeta(this.formMetaData);
    const t = m?.formConfig?.formTitle;
    return typeof t === 'string' ? t : '';
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.cdr.detectChanges();
      return;
    }
    const payload = this.form.getRawValue() as Record<string, unknown>;
    this.actionListnerEvent.emit(payload);
  }

  onCancel(): void {
    this.formCancelConfirmEvent.emit();
  }

  ngOnDestroy(): void {
    this.formValueSub?.unsubscribe();
  }
}
