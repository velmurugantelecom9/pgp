import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { Sort } from '@angular/material/sort';
import {
  ActionRecordSelectionState,
  GenericRow,
  MdsConfigurableRichDataGrid,
  NoRecordsFoundModel,
  RichDataGridModel,
} from '../../models/rich-data-grid.model';

@Component({
  selector: 'lib-rich-data-grid',
  templateUrl: './rich-data-grid.component.html',
  styleUrls: ['./rich-data-grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LibRichDataGridComponent implements OnChanges, OnInit {
  @Input() noRecordsFoundModel: NoRecordsFoundModel | null = null;
  @Input() mdsRichDataGrid: MdsConfigurableRichDataGrid = { richDataGridConfig: [] };
  @Input() dataGridModel: RichDataGridModel = {};
  @Input() pageSize = 10;
  @Input() pageNumber = 0;
  @Input() pageSizeOptions: number[] = [5, 10, 20, 50];
  @Input() hidePageSize = false;
  @Input() locales: Record<string, string> = {};
  /** Flat array of rows from JSON – no group concept */
  @Input() records: GenericRow[] = [];
  @Input() displayedColumns: string[] = [];

  @Output() dataGridAction = new EventEmitter<ActionRecordSelectionState>();
  @Output() linkClick = new EventEmitter<string>();
  @Output() refreshGrid = new EventEmitter<{ pageIndex?: number; pageSize?: number; sort?: Sort }>();

  /** Data source connected to paginator – table shows current page only */
  dataSource = new MatTableDataSource<GenericRow>([]);

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(
    private cdRef: ChangeDetectorRef,
    public matPaginatorIntl: MatPaginatorIntl,
    private liveAnnouncer: LiveAnnouncer
  ) {}

  ngAfterViewInit(): void {
    if (this.locales?.['rowsPerPage']) {
      this.matPaginatorIntl.itemsPerPageLabel = this.locales['rowsPerPage'];
    }
    this.dataSource.paginator = this.paginator;
    if (this.paginator) {
      this.paginator.pageSize = this.pageSize;
      this.paginator.pageIndex = this.pageNumber;
    }
    this.cdRef.markForCheck();
  }

  ngOnInit(): void {
    this.dataSource.data = this.records || [];
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['records']) {
      this.dataSource.data = this.records || [];
      if (this.paginator) {
        this.paginator.pageIndex = this.pageNumber;
        this.paginator.pageSize = this.pageSize;
      }
      this.cdRef.markForCheck();
    }
  }

  trackWithId(_index: number, record: GenericRow): string {
    const id = record.id;
    return typeof id === 'string' ? id : (id != null && typeof (id as { url?: string }).url === 'string' ? (id as { url: string }).url : String(id));
  }

  /** Stable row id for actions (string); supports id as link object */
  getRecordId(record: GenericRow): string {
    const id = record.id;
    return typeof id === 'string' ? id : (id != null && typeof (id as { url?: string }).url === 'string' ? (id as { url: string }).url : '');
  }

  /** Emit action (e.g. approve/reject) with groupIndex 0 for flat list */
  initiateAction(selectedAction: string, _groupIndex: number, id: string): void {
    this.dataGridAction.emit({ selectedAction, groupIndex: 0, recordId: id });
  }

  /** Material Icons ligature name for grid action buttons */
  actionIconName(action: string): string {
    const map: Record<string, string> = {
      edit: 'edit',
      delete: 'delete',
      approve: 'check',
      reject: 'close',
    };
    return map[action] ?? action;
  }

  actionButtonColor(action: string): 'primary' | 'warn' | undefined {
    if (action === 'reject' || action === 'delete') return 'warn';
    return undefined;
  }

  actionAriaLabel(action: string): string {
    const map: Record<string, string> = {
      edit: 'Edit',
      delete: 'Delete',
      approve: 'Approve',
      reject: 'Reject',
    };
    return map[action] ?? action;
  }

  announceSortChange(sortState: Sort): void {
    if (sortState.direction) {
      this.liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this.liveAnnouncer.announce('Sorting cleared');
    }
  }

  onSortOrPage(event: Sort | { pageIndex: number; pageSize: number; length: number }): void {
    if (!('direction' in event)) {
      this.refreshGrid.emit({ pageIndex: event.pageIndex, pageSize: event.pageSize });
    } else {
      this.refreshGrid.emit({ sort: event });
    }
  }

  onLinkClick(url: string): void {
    this.linkClick.emit(url);
  }
}
