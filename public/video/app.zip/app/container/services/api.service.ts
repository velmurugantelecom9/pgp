import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import type { ContactRecord } from '../../contacts/models/contact.model';

/** Firebase Realtime Database — `contact` node: list, create, and single-record read/update/delete. */
const CONTACT_BASE_URL = 'https://hyundai-812bb-default-rtdb.firebaseio.com/contact';

/**
 * Optional seed shape for documentation / tests. Realtime DB stores JSON under `contact.json`.
 * POST creates a child with an auto id; PUT uses a chosen id as the path segment.
 */
/**
 * Firebase Realtime Database `GET .../contact.json` returns:
 * - `null` if empty
 * - `{ [pushId]: { name, emailAddress, ... } }` for records created with POST
 * - or a single object if stored differently
 */
export function parseFirebaseContactsPayload(data: unknown): ContactRecord[] {
  if (data == null) {
    return [];
  }
  if (Array.isArray(data)) {
    return data.map((row, idx) => firebaseEntryToRecord(String((row as { id?: string })?.id ?? idx), row));
  }
  if (typeof data === 'object') {
    return Object.entries(data as Record<string, unknown>).map(([key, value]) =>
      firebaseEntryToRecord(key, value)
    );
  }
  return [];
}

function firebaseEntryToRecord(firebaseKey: string, value: unknown): ContactRecord {
  const v = value && typeof value === 'object' ? (value as Record<string, unknown>) : {};
  return {
    id: firebaseKey,
    name: v['name'] != null ? String(v['name']) : undefined,
    code: v['code'] != null ? String(v['code']) : undefined,
    dateOfBirth: v['dateOfBirth'] != null ? String(v['dateOfBirth']) : undefined,
    gender: v['gender'] != null ? String(v['gender']) : undefined,
    mobileNumber: v['mobileNumber'] != null ? String(v['mobileNumber']) : undefined,
    emailAddress: v['emailAddress'] != null ? String(v['emailAddress']) : undefined,
    status: v['status'] != null ? String(v['status']) : undefined,
    identityDetails: v['identityDetails'] != null ? String(v['identityDetails']) : undefined,
    aadhaarNumber: v['aadhaarNumber'] != null ? String(v['aadhaarNumber']) : undefined,
    panNumber: v['panNumber'] != null ? String(v['panNumber']) : undefined,
    maritalStatus: v['maritalStatus'] != null ? String(v['maritalStatus']) : undefined,
  };
}

export const CONTACT_SAMPLE_PAYLOAD: Record<string, unknown> = {
  name: 'Arun Kumar',
  dateOfBirth: '1992-01-14',
  gender: 'male',
  mobileNumber: '9876543210',
  emailAddress: 'arun.kumar@example.com',
  status: 'active',
  identityDetails: 'aadhaar',
  aadhaarNumber: '123412341234',
  panNumber: '',
  maritalStatus: 'single',
};

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) {}

  /** Full contact node (same as `getContactData`). */
  getData(): Observable<unknown> {
    return this.http.get(`${CONTACT_BASE_URL}.json`);
  }

  getContactData(): Observable<unknown> {
    return this.getData();
  }

  /** POST — appends a new record under `contact` (Firebase returns `{ name: "<newId>" }`). */
  saveContactData(body: unknown): Observable<unknown> {
    return this.http.post(`${CONTACT_BASE_URL}.json`, body);
  }

  /** PUT — replace the record at `contact/<id>`. */
  updateContactData(id: string, body: unknown): Observable<unknown> {
    return this.http.put(`${CONTACT_BASE_URL}/${id}.json`, body);
  }

  deleteContactData(id: string): Observable<unknown> {
    return this.http.delete(`${CONTACT_BASE_URL}/${id}.json`);
  }

  /**
   * Load one contact for edit — same path as list children: `GET .../contact/{id}.json`
   * Example: `https://hyundai-812bb-default-rtdb.firebaseio.com/contact/-OopAGUH6UsVOBjAbSql.json`
   */
  getContactForEdit(id: string): Observable<unknown> {
    const key = encodeURIComponent(id);
    return this.http.get(`${CONTACT_BASE_URL}/${key}.json`);
  }

  /** PUT — same path as `getContactForEdit`: `.../contact/{id}.json`. */
  updateContactForEdit(id: string, body: unknown): Observable<unknown> {
    return this.updateContactData(id, body);
  }
}
