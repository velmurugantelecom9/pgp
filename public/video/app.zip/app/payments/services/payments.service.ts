import { Injectable } from '@angular/core';
import { Payment } from '../models/payment.model';

@Injectable({ providedIn: 'root' })
export class PaymentsService {
  private payments: Payment[] = [
    { id: '1', customer: 'Customer A', businessProduct: 'Business product A' },
    { id: '2', customer: 'Customer B', businessProduct: 'Business product B' },
  ];
  private idCounter = 3;

  getAll(): Payment[] {
    return [...this.payments];
  }

  getById(id: string): Payment | undefined {
    return this.payments.find((p) => p.id === id);
  }

  create(customer: string, businessProduct: string): Payment {
    const payment: Payment = {
      id: String(this.idCounter++),
      customer,
      businessProduct,
    };
    this.payments.push(payment);
    return payment;
  }

  update(id: string, customer: string, businessProduct: string): Payment | null {
    const index = this.payments.findIndex((p) => p.id === id);
    if (index === -1) return null;
    this.payments[index] = { id, customer, businessProduct };
    return this.payments[index];
  }

  delete(id: string): boolean {
    const index = this.payments.findIndex((p) => p.id === id);
    if (index === -1) return false;
    this.payments.splice(index, 1);
    return true;
  }
}
