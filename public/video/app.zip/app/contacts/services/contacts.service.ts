import { Injectable } from '@angular/core';
import { Contact } from '../models/contact.model';

@Injectable({ providedIn: 'root' })
export class ContactsService {
  private contacts: Contact[] = [
    {
      id: '1',
      email: 'arun.kumar@example.com',
      phone: '9876543210',
      dynamicFields: {
        name: 'Arun Kumar',
        dateOfBirth: '1992-01-14',
        gender: 'male',
        mobileNumber: '9876543210',
        emailAddress: 'arun.kumar@example.com',
        status: 'active',
        identityDetails: 'aadhaar',
        aadhaarNumber: '123412341234',
        panNumber: '',
        maritalStatus: 'single',
      },
    },
    {
      id: '2',
      email: 'divya.nair@example.com',
      phone: '9123456780',
      dynamicFields: {
        name: 'Divya Nair',
        dateOfBirth: '1995-06-08',
        gender: 'female',
        mobileNumber: '9123456780',
        emailAddress: 'divya.nair@example.com',
        status: 'active',
        identityDetails: 'pan',
        aadhaarNumber: '',
        panNumber: 'ABCDE1234F',
        maritalStatus: 'married',
      },
    },
    {
      id: '3',
      email: 'rohit.sharma@example.com',
      phone: '9345678901',
      dynamicFields: {
        name: 'Rohit Sharma',
        dateOfBirth: '1989-09-21',
        gender: 'male',
        mobileNumber: '9345678901',
        emailAddress: 'rohit.sharma@example.com',
        status: 'inactive',
        identityDetails: 'aadhaar',
        aadhaarNumber: '234523452345',
        panNumber: '',
        maritalStatus: 'married',
      },
    },
    {
      id: '4',
      email: 'keerthi.rao@example.com',
      phone: '9456789012',
      dynamicFields: {
        name: 'Keerthi Rao',
        dateOfBirth: '1998-03-30',
        gender: 'female',
        mobileNumber: '9456789012',
        emailAddress: 'keerthi.rao@example.com',
        status: 'active',
        identityDetails: 'pan',
        aadhaarNumber: '',
        panNumber: 'BCDEF2345G',
        maritalStatus: 'single',
      },
    },
    {
      id: '5',
      email: 'manoj.verma@example.com',
      phone: '9567890123',
      dynamicFields: {
        name: 'Manoj Verma',
        dateOfBirth: '1991-12-11',
        gender: 'male',
        mobileNumber: '9567890123',
        emailAddress: 'manoj.verma@example.com',
        status: 'pending',
        identityDetails: 'aadhaar',
        aadhaarNumber: '345634563456',
        panNumber: '',
        maritalStatus: 'single',
      },
    },
    {
      id: '6',
      email: 'sneha.iyer@example.com',
      phone: '9678901234',
      dynamicFields: {
        name: 'Sneha Iyer',
        dateOfBirth: '1993-07-19',
        gender: 'female',
        mobileNumber: '9678901234',
        emailAddress: 'sneha.iyer@example.com',
        status: 'active',
        identityDetails: 'pan',
        aadhaarNumber: '',
        panNumber: 'CDEFG3456H',
        maritalStatus: 'married',
      },
    },
    {
      id: '7',
      email: 'prakash.singh@example.com',
      phone: '9789012345',
      dynamicFields: {
        name: 'Prakash Singh',
        dateOfBirth: '1987-10-03',
        gender: 'male',
        mobileNumber: '9789012345',
        emailAddress: 'prakash.singh@example.com',
        status: 'inactive',
        identityDetails: 'aadhaar',
        aadhaarNumber: '456745674567',
        panNumber: '',
        maritalStatus: 'married',
      },
    },
    {
      id: '8',
      email: 'asha.menon@example.com',
      phone: '9890123456',
      dynamicFields: {
        name: 'Asha Menon',
        dateOfBirth: '1996-05-25',
        gender: 'female',
        mobileNumber: '9890123456',
        emailAddress: 'asha.menon@example.com',
        status: 'active',
        identityDetails: 'pan',
        aadhaarNumber: '',
        panNumber: 'DEFGH4567J',
        maritalStatus: 'single',
      },
    },
    {
      id: '9',
      email: 'hari.krishna@example.com',
      phone: '9901234567',
      dynamicFields: {
        name: 'Hari Krishna',
        dateOfBirth: '1990-11-02',
        gender: 'male',
        mobileNumber: '9901234567',
        emailAddress: 'hari.krishna@example.com',
        status: 'pending',
        identityDetails: 'aadhaar',
        aadhaarNumber: '567856785678',
        panNumber: '',
        maritalStatus: 'single',
      },
    },
    {
      id: '10',
      email: 'lakshmi.devi@example.com',
      phone: '9012345678',
      dynamicFields: {
        name: 'Lakshmi Devi',
        dateOfBirth: '1994-02-16',
        gender: 'female',
        mobileNumber: '9012345678',
        emailAddress: 'lakshmi.devi@example.com',
        status: 'active',
        identityDetails: 'pan',
        aadhaarNumber: '',
        panNumber: 'EFGHI5678K',
        maritalStatus: 'married',
      },
    },
    {
      id: '11',
      email: 'naveen.das@example.com',
      phone: '9123456701',
      dynamicFields: {
        name: 'Naveen Das',
        dateOfBirth: '1988-08-09',
        gender: 'male',
        mobileNumber: '9123456701',
        emailAddress: 'naveen.das@example.com',
        status: 'inactive',
        identityDetails: 'aadhaar',
        aadhaarNumber: '678967896789',
        panNumber: '',
        maritalStatus: 'married',
      },
    },
    {
      id: '12',
      email: 'meera.joshi@example.com',
      phone: '9234567012',
      dynamicFields: {
        name: 'Meera Joshi',
        dateOfBirth: '1997-04-27',
        gender: 'female',
        mobileNumber: '9234567012',
        emailAddress: 'meera.joshi@example.com',
        status: 'pending',
        identityDetails: 'pan',
        aadhaarNumber: '',
        panNumber: 'FGHIJ6789L',
        maritalStatus: 'single',
      },
    },
  ];
  private idCounter = 13;

  getAll(): Contact[] {
    return [...this.contacts];
  }

  getById(id: string): Contact | undefined {
    return this.contacts.find((c) => c.id === id);
  }

  create(email: string, phone: string): Contact {
    const contact: Contact = {
      id: String(this.idCounter++),
      email,
      phone,
    };
    this.contacts.push(contact);
    return contact;
  }

  /** Create contact from JSON-driven form payload (sectionId__fieldId keys). */
  createFromDynamicForm(payload: Record<string, unknown>): Contact {
    const email =
      this.pickString(payload, [
        'emailAddress',
        'basicDetails__emailAddress',
        'communicationDetails__counterpartyEmail',
        'secContactInformation__code',
      ]) || 'contact@example.com';
    const phone =
      this.pickString(payload, [
        'mobileNumber',
        'basicDetails__mobileNumber',
        'communicationDetails__mobileNumber',
        'communicationDetails__faxNumber',
      ]) || '';
    const contact: Contact = {
      id: String(this.idCounter++),
      email,
      phone,
      dynamicFields: { ...payload },
    };
    this.contacts.push(contact);
    return contact;
  }

  update(id: string, email: string, phone: string): Contact | null {
    const index = this.contacts.findIndex((c) => c.id === id);
    if (index === -1) return null;
    this.contacts[index] = { ...this.contacts[index], id, email, phone };
    return this.contacts[index];
  }

  updateFromDynamicForm(id: string, payload: Record<string, unknown>): Contact | null {
    const index = this.contacts.findIndex((c) => c.id === id);
    if (index === -1) return null;
    const prev = this.contacts[index];
    const email =
      this.pickString(payload, [
        'emailAddress',
        'basicDetails__emailAddress',
        'communicationDetails__counterpartyEmail',
      ]) || prev.email;
    const phone =
      this.pickString(payload, ['mobileNumber', 'basicDetails__mobileNumber', 'communicationDetails__mobileNumber']) ||
      prev.phone;
    this.contacts[index] = {
      ...prev,
      id,
      email,
      phone,
      dynamicFields: { ...payload },
    };
    return this.contacts[index];
  }

  private pickString(payload: Record<string, unknown>, keys: string[]): string {
    for (const k of keys) {
      const v = payload[k];
      if (v !== undefined && v !== null && String(v).trim() !== '') {
        return String(v);
      }
    }
    return '';
  }

  delete(id: string): boolean {
    const index = this.contacts.findIndex((c) => c.id === id);
    if (index === -1) return false;
    this.contacts.splice(index, 1);
    return true;
  }
}
