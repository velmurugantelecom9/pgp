export interface Contact {
  id: string;
  /** Legacy demo fields (list may still show these when present) */
  email: string;
  phone: string;
  /** Flattened dynamic form values from JSON-driven contact form (sectionId__fieldId → value) */
  dynamicFields?: Record<string, unknown>;
}

/** API contact record (data.records[] from API) */
export interface ContactRecord {
  id: string;
  nextActions?: string;
  corporateId?: string;
  type?: string;
  name?: string;
  code?: string;
  alias?: string;
  dateOfBirth?: string;
  gender?: string;
  mobileNumber?: string;
  emailAddress?: string;
  identityDetails?: string;
  aadhaarNumber?: string;
  panNumber?: string;
  maritalStatus?: string;
  classification?: string | null;
  idType?: string | null;
  createdBy?: string;
  createdTs?: string;
  contactAccounts?: Array<{ accountName?: string | null; __typename?: string }>;
  status?: string;
  corporate?: { name?: string; __typename?: string } | null;
  creatorInfo?: unknown;
  __typename?: string;
  [key: string]: unknown;
}

/** API response: { data: { count: [...], records: [...] } } */
export interface ContactDataResponse {
  data: {
    count?: Array<{ total?: number; __typename?: string }>;
    records: ContactRecord[];
  };
}

/** Display row for rich data grid (mapped from ContactRecord) */
export interface ContactDisplayRecord {
  id: string;
  contactRefNo: { label: string; url: string };
  name: string;
  dateOfBirth: string;
  gender: string;
  mobileNumber: string;
  emailAddress: string;
  status: string;
  identityDetails: string;
  aadhaarNumber: string;
  panNumber: string;
  maritalStatus: string;
  [key: string]: unknown;
}
