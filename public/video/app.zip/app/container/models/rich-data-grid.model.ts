/**
 * Link object for id/link columns (optional alternative to string id).
 */
export interface GenericRowLinkId {
  label: string;
  url: string;
}

/**
 * Generic row with required id; other properties are column values.
 * id can be a string (row identifier) or a link object for the id column display.
 */
export interface GenericRow {
  id: string | GenericRowLinkId;
  [key: string]: unknown;
}

/**
 * Column configuration for the rich data grid.
 */
export interface RichDataGridColumnConfig {
  id: string;
  columnName: string;
  customLabel?: string;
  alignment?: 'left' | 'right';
  isFreezed?: boolean;
  isColumnDragApplicable?: boolean;
  type?: 'text' | 'actions' | 'primaryActions' | 'link' | 'objectLabel';
  sortWith?: string;
  hidden?: boolean;
  children?: RichDataGridColumnConfig[];
  cellTemplate?: string;
  columnTemplate?: string;
  actions?: string[];
  primaryActions?: { buttonAction: string; actionLabel?: string; iconClass?: string; isDisabled?: boolean }[];
}

/**
 * Group of rows (e.g. for accordion or logical grouping).
 */
export interface GenericGroup<T = GenericRow> {
  groupName: string;
  groupCount: number;
  records: T[];
  groupAmount?: { label?: string; value?: number; currencyCode?: string };
  groupReferenceAmount?: { label?: string; value?: number; currencyCode?: string };
  groupTransactionAmounts?: Array<{ labelLocaleKey?: string; amount?: unknown; class?: string; amountIndicator?: string }>;
  [key: string]: unknown;
}

/**
 * Per-record state (selection, expanded, selected action).
 */
export interface RecordState {
  rowId?: string;
  isSelected: boolean;
  isSelectionDisabled?: boolean;
  isExpanded?: boolean;
  selectedAction?: string;
  navUrl?: string;
  expandRowTemplate?: string;
}

/**
 * State for a single group (page selection, sort, expanded, record states).
 */
export interface GroupRowState<T = GenericRow> {
  groupName?: string;
  isExpanded?: boolean;
  isSelected?: boolean;
  loading?: boolean;
  isPageSelected?: boolean;
  hasActionSelected?: boolean;
  selectedPageAction?: string;
  selectedRecords?: T[];
  recordState: Record<string, RecordState>;
  sort?: Record<string, { order: number }>;
}

/**
 * Emitted when a record is selected or deselected.
 */
export interface RecordSelectionState<T = GenericRow> {
  selected: boolean;
  record: T;
  groupIndex: number;
}

/**
 * Sort state for a column (e.g. asc = 1, desc = -1).
 */
export interface SortState {
  [columnName: string]: { order: number };
}

/**
 * Emitted when grid refresh is requested (sort, page, etc.).
 */
export interface DatagridRefreshModel {
  group?: GenericGroup;
  groupIndex?: number;
  state?: unknown;
}

/**
 * Configurable rich data grid (column config + optional template refs).
 */
export interface MdsConfigurableRichDataGrid {
  richDataGridConfig?: RichDataGridColumnConfig[];
  dataGridModel?: Record<string, { class?: string; sortWith?: string; hidden?: boolean }>;
  getTemplateRef?(name: string): unknown;
  getCellTemplateRef?(name: string): unknown;
}

/**
 * No-records placeholder model.
 */
export interface NoRecordsFoundModel {
  title?: string;
  message?: string;
  [key: string]: unknown;
}

/**
 * Rich data grid model (column id -> display config).
 */
export type RichDataGridModel = Record<string, { class?: string; sortWith?: string; hidden?: boolean }>;

/**
 * Selected group summary.
 */
export interface SelectedGroup {
  groupIndex: number;
  [key: string]: unknown;
}

/**
 * Action/record selection for workflow.
 */
export interface ActionRecordSelectionState {
  selectedAction: string;
  groupIndex: number;
  recordId: string;
}

/**
 * Multi-action page selection.
 */
export interface MultiActionSelectionState {
  selectedAction: string;
  groupIndex: number;
}

/**
 * Expanded state change for accordion.
 */
export interface ExpandedChangeModel {
  groupIndex: number;
  isExpanded: boolean;
}
