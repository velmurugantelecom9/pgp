import { Component, Input } from '@angular/core';

/** Main text with optional icon */
export interface TextTemplateMainText {
  iconName?: string;
  value: string;
}

/** Sub text entry */
export interface TextTemplateSubText {
  class?: string;
  iconName?: string;
  value: string;
}

/** Object shape for text template when data is an object */
export interface TextTemplateObject {
  mainText: TextTemplateMainText;
  subText?: TextTemplateSubText[];
}

@Component({
  selector: 'lib-text-template',
  templateUrl: './text-template.component.html',
  styleUrls: ['./text-template.component.scss'],
})
export class LibTextTemplateComponent {
  /** Cell value: string, array of strings, or object with mainText/subText */
  @Input() data: unknown = null;

  /** Array of strings when data is an array */
  get textList(): string[] {
    return Array.isArray(this.data) ? (this.data as string[]) : [];
  }

  /** Object when data is an object with mainText/subText */
  get textObject(): TextTemplateObject | null {
    if (this.data != null && typeof this.data === 'object' && !Array.isArray(this.data)) {
      return this.data as TextTemplateObject;
    }
    return null;
  }

  isArray(val: unknown): boolean {
    return Array.isArray(val);
  }

  isObject(val: unknown): boolean {
    return typeof val === 'object' && val !== null && !Array.isArray(val);
  }
}
