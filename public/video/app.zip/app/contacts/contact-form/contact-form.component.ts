import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';
import { ContactsService } from '../services/contacts.service';
import { ApiService } from '../../container/services/api.service';
import { FormJsonLoaderService } from '../../container/services/form-json-loader.service';
import type { FabricFormMeta, FabricFormOption } from '../../container/models/fabric-form.model';

const CONTACT_FORM_CONFIG_URL = '/assets/config/contact-form-config.json';
const CONTACT_EDIT_FORM_CONFIG_URL = '/assets/config/contact-edit-form-config.json';
const CONTACT_DROPDOWN_DATA_URL = '/assets/config/contact-form-dropdown-data.json';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.scss'],
})
export class ContactFormComponent implements OnInit {
  /** True when URL is `/contacts/edit/:id` — loads `contact-edit-form-config.json` and sets dynamic form edit mode. */
  editMode = false;
  contactId: string | null = null;
  formMetaData: FabricFormMeta | null = null;
  editPatch: Record<string, unknown> | null = null;
  dropdownData: Record<string, FabricFormOption[]> = {};
  configLoading = true;
  configError: string | null = null;

  constructor(
    private formLoader: FormJsonLoaderService,
    private contactsService: ContactsService,
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadFormAssets();
  }

  get hasSections(): boolean {
    return (this.formMetaData?.formSectionConfig?.length ?? 0) > 0;
  }

  get pageTitle(): string {
    const t = this.formMetaData?.formConfig?.formTitle;
    if (typeof t === 'string' && t) {
      return t;
    }
    return 'Contact';
  }

  /**
   * Load dropdown + form JSON in parallel. Always clears `configLoading` in `finalize`
   * and runs change detection so the UI cannot stay stuck on "Loading form…".
   */
  private loadFormAssets(): void {
    this.configLoading = true;
    this.configError = null;

    const id = this.route.snapshot.paramMap.get('id');
    this.contactId = id;
    this.editMode = !!id;

    const formConfigUrl = this.editMode ? CONTACT_EDIT_FORM_CONFIG_URL : CONTACT_FORM_CONFIG_URL;

    const remoteContact$ =
      this.editMode && id
        ? this.apiService.getContactForEdit(id).pipe(catchError(() => of(null)))
        : of(null);

    forkJoin({
      dropdown: this.formLoader.loadDropdownData(CONTACT_DROPDOWN_DATA_URL).pipe(
        catchError(() => of({} as Record<string, FabricFormOption[]>))
      ),
      form: this.formLoader.loadFormMetaData(formConfigUrl).pipe(
        catchError(() => of(null as FabricFormMeta | null))
      ),
      remoteContact: remoteContact$,
    })
      .pipe(
        tap(({ dropdown, form, remoteContact }) => {
          this.dropdownData = dropdown ?? {};
          if (form) {
            this.formMetaData = this.formLoader.transform(form);
            if (this.editMode && id) {
              if (remoteContact && typeof remoteContact === 'object' && remoteContact !== null) {
                this.editPatch = { ...(remoteContact as Record<string, unknown>) };
              } else {
                const contact = this.contactsService.getById(id);
                this.editPatch = contact?.dynamicFields
                  ? ({ ...contact.dynamicFields } as Record<string, unknown>)
                  : null;
              }
            } else {
              this.editPatch = null;
            }
            this.configError = null;
          } else {
            this.formMetaData = null;
            this.editPatch = null;
            const expectedFile = this.editMode ? 'contact-edit-form-config.json' : 'contact-form-config.json';
            this.configError = `Could not load contact form configuration. Check that /assets/config/${expectedFile} exists and is valid JSON.`;
          }
        }),
        finalize(() => {
          this.configLoading = false;
          this.cdr.detectChanges();
        })
      )
      .subscribe();
  }

  actionListnerEvent(payload: Record<string, unknown>): void {
    const persistLocal = (): void => {
      if (this.editMode && this.contactId) {
        this.contactsService.updateFromDynamicForm(this.contactId, payload);
      } else {
        this.contactsService.createFromDynamicForm(payload);
      }
      this.router.navigate(['/contacts']);
    };

    const request$ =
      this.editMode && this.contactId
        ? this.apiService.updateContactForEdit(this.contactId, payload)
        : this.apiService.saveContactData(payload);

    request$.subscribe({
      next: () => persistLocal(),
      error: (err) => {
        console.error('Contact Firebase API error', err);
        persistLocal();
      },
    });
  }

  onFormCancelConfirmEvent(): void {
    this.router.navigate(['/contacts']);
  }
}
