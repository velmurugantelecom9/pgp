export interface Payment {
  id: string;
  customer: string;
  businessProduct: string;
}

export const CUSTOMER_OPTIONS = ['Customer A', 'Customer B', 'Customer C'] as const;
export const BUSINESS_PRODUCT_OPTIONS = ['Business product A', 'Business product B', 'Business product C'] as const;
