import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentsService } from '../services/payments.service';
import { Payment } from '../models/payment.model';
import { FormJsonLoaderService } from '../../container/services/form-json-loader.service';
import type { FabricFormMeta, FabricFormOption } from '../../container/models/fabric-form.model';

const PAYMENT_FORM_CONFIG_URL = '/assets/config/payment-form-config.json';
const PAYMENT_DROPDOWN_DATA_URL = '/assets/config/payment-form-dropdown-data.json';

/** Keys produced by `dds-fabric-form` for the first payment section (see payment-form-config.json). */
const KEY_CORPORATE = 'secPaymentType__corporateId';
const KEY_SUBPRODUCT = 'secPaymentType__subproductCode';

@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.scss'],
})
export class PaymentFormComponent implements OnInit {
  isEdit = false;
  paymentId: string | null = null;
  formMetaData: FabricFormMeta | null = null;
  editPatch: Record<string, unknown> | null = null;
  dropdownData: Record<string, FabricFormOption[]> = {};
  configLoading = true;
  configError: string | null = null;

  constructor(
    private formLoader: FormJsonLoaderService,
    private paymentsService: PaymentsService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadDropdownThenForm();
  }

  get hasSections(): boolean {
    return (this.formMetaData?.formSectionConfig?.length ?? 0) > 0;
  }

  get pageTitle(): string {
    const t = this.formMetaData?.formConfig?.formTitle;
    if (typeof t === 'string' && t) {
      return t;
    }
    return 'Create Payment';
  }

  private loadDropdownThenForm(): void {
    this.formLoader.loadDropdownData(PAYMENT_DROPDOWN_DATA_URL).subscribe({
      next: (data) => {
        this.dropdownData = data;
        this.loadFormConfig();
      },
      error: () => {
        this.dropdownData = {};
        this.loadFormConfig();
      },
    });
  }

  private loadFormConfig(): void {
    this.configLoading = true;
    this.configError = null;
    this.formLoader.loadFormMetaData(PAYMENT_FORM_CONFIG_URL).subscribe({
      next: (raw) => {
        this.formMetaData = this.formLoader.transform(raw);
        const id = this.route.snapshot.paramMap.get('id');
        this.isEdit = !!id;
        this.paymentId = id;
        const payment = id ? this.paymentsService.getById(id) : undefined;
        this.editPatch = payment && this.formMetaData ? this.buildPaymentEditPatch(payment) : null;
        this.configLoading = false;
        this.cdr.markForCheck();
      },
      error: () => {
        this.formMetaData = null;
        this.editPatch = null;
        this.configLoading = false;
        this.configError =
          'Could not load payment form configuration. Check that /assets/config/payment-form-config.json exists and is valid JSON.';
        this.cdr.markForCheck();
      },
    });
  }

  /** Map in-memory Payment to flat `sectionId__fieldId` keys used by the dynamic form. */
  private buildPaymentEditPatch(payment: Payment): Record<string, unknown> | null {
    const patch: Record<string, unknown> = {};
    patch[KEY_CORPORATE] = payment.customer;
    patch[KEY_SUBPRODUCT] = payment.businessProduct;
    return patch;
  }

  actionListnerEvent(payload: Record<string, unknown>): void {
    const customer = this.stringifyPayloadValue(payload[KEY_CORPORATE]);
    const businessProduct = this.stringifyPayloadValue(payload[KEY_SUBPRODUCT]);

    if (this.isEdit && this.paymentId) {
      this.paymentsService.update(this.paymentId, customer, businessProduct);
    } else {
      this.paymentsService.create(customer, businessProduct);
    }
    this.router.navigate(['/payments']);
  }

  private stringifyPayloadValue(value: unknown): string {
    if (value === null || value === undefined) {
      return '';
    }
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      return String(value);
    }
    if (typeof value === 'object' && value !== null && 'elementLabel' in (value as object)) {
      return String((value as { elementLabel?: unknown }).elementLabel ?? '');
    }
    return String(value);
  }

  onFormCancelConfirmEvent(): void {
    this.router.navigate(['/payments']);
  }
}
