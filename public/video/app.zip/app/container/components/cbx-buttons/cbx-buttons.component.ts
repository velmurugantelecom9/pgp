import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { ButtonModel, GenericObject } from '../../models/button.model';

@Component({
  selector: 'cbx-buttons',
  templateUrl: './cbx-buttons.component.html',
  styleUrls: ['./cbx-buttons.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CbxButtonsComponent implements OnChanges {
  @Input() buttons: ButtonModel[] = [];
  @Input() inprogress = false;
  @Input() isInline = false;
  @Input() attrId = '';
  @Input() formName = '';
  @Input() locales: GenericObject = {};

  @Output() buttonClick = new EventEmitter<ButtonModel>();

  clickedButtonId = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['inprogress'] && !changes['inprogress'].currentValue) {
      this.clickedButtonId = '';
    }
    this.buttons = this.buttons || [];
  }

  onButtonClick(data: ButtonModel): void {
    this.clickedButtonId = data.id;
    this.buttonClick.emit(data);
  }
}
