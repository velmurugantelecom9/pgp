import { Component, Input } from '@angular/core';

@Component({
  selector: 'lib-data-list-template',
  templateUrl: './data-list-template.component.html',
  styleUrls: ['./data-list-template.component.scss'],
})
export class LibDataListTemplateComponent {
  /** List of values to render */
  @Input() dataList: unknown[] = [];

  /** Optional list of CSS classes, one per item (index-aligned with dataList) */
  @Input() classList: string[] = [];
}
