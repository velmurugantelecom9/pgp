import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonComponent } from './components/button/button.component';
import { CbxButtonsComponent } from './components/cbx-buttons/cbx-buttons.component';
import { LibRichDataGridComponent } from './components/rich-data-grid/rich-data-grid.component';
import { LibTextTemplateComponent } from './components/text-template/text-template.component';
import { LibDataListTemplateComponent } from './components/data-list-template/data-list-template.component';
import { LibStatusTemplateComponent } from './components/status-template/status-template.component';
import { DdsFabricFormComponent } from './components/dds-fabric-form/dds-fabric-form.component';
import { CbxDynamicFormComponent } from './components/cbx-dynamic-form/cbx-dynamic-form.component';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { A11yModule } from '@angular/cdk/a11y';

@NgModule({
  declarations: [
    ButtonComponent,
    CbxButtonsComponent,
    LibRichDataGridComponent,
    LibTextTemplateComponent,
    LibDataListTemplateComponent,
    LibStatusTemplateComponent,
    DdsFabricFormComponent,
    CbxDynamicFormComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    A11yModule,
    MatTableModule,
    MatSortModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatExpansionModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
  ],
  exports: [
    CbxButtonsComponent,
    ButtonComponent,
    LibRichDataGridComponent,
    LibTextTemplateComponent,
    LibDataListTemplateComponent,
    LibStatusTemplateComponent,
    DdsFabricFormComponent,
    CbxDynamicFormComponent,
  ],
})
export class ContainerModule {}
