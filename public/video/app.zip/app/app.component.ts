import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="app-container">
      <header class="app-header">
        <h1>Midas CRUD</h1>
        <nav>
          <a routerLink="/contacts" routerLinkActive="active">Contacts</a>
          <a routerLink="/payments" routerLinkActive="active">Payments</a>
        </nav>
      </header>
      <main class="app-content">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
  styles: [`
    .app-container { min-height: 100vh; display: flex; flex-direction: column; }
    .app-header {
      background: #1976d2;
      color: white;
      padding: 1rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .app-header h1 { margin: 0; font-size: 1.5rem; font-weight: 500; }
    .app-header nav a {
      color: rgba(255,255,255,0.9);
      text-decoration: none;
      margin-left: 1rem;
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
    }
    .app-header nav a:hover { background: rgba(255,255,255,0.1); }
    .app-header nav a.active { background: rgba(255,255,255,0.2); color: white; }
    .app-content { flex: 1; padding: 2rem; }
  `],
})
export class AppComponent {}
