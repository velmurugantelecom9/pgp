import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { ButtonModel, GenericObject } from '../../models/button.model';

@Component({
  selector: 'cbx-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ButtonComponent implements OnChanges {
  @Input() data: ButtonModel = {} as ButtonModel;
  @Input() isDisabled = false;
  @Input() isLoading = false;
  @Input() isInline = false;
  @Input() buttonType: 'submit' | 'button' = 'button';
  @Input() formName = '';
  @Input() attrId = 'button';
  @Input() locales: GenericObject = {};

  @Output() buttonClick = new EventEmitter<ButtonModel>();

  /** Resolved id for the button element (attrId + data.id when both set) */
  computedAttrId = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (this.attrId && this.data?.id) {
      this.computedAttrId = `${this.attrId}-${this.data.id}`;
    } else {
      this.computedAttrId = (this.attrId || this.data?.id || '') as string;
    }
  }

  onClick(event?: Event): void {
    if (this.isDisabled || this.isLoading) {
      return;
    }
    if (this.buttonType === 'submit' && event) {
      event.preventDefault();
    }
    this.buttonClick.emit(this.data);
  }

  /** Display text: name (sample API) or label (backward compatibility) */
  get buttonText(): string {
    return (this.data?.name ?? this.data?.label ?? '') as string;
  }
}
