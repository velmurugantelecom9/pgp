import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ContactRecord, ContactDisplayRecord } from '../models/contact.model';
import { ContactTableConfig, ContactTableColumnConfig } from '../models/contact-table-config.model';
import { CONTACT_CENTER_DATA } from '../data/contact-center.data';
import {
  MdsConfigurableRichDataGrid,
  RichDataGridModel,
  RichDataGridColumnConfig,
  ActionRecordSelectionState,
} from '../../container/models/rich-data-grid.model';
import { ButtonModel } from '../../container/models/button.model';
import { ApiService, parseFirebaseContactsPayload } from '../../container/services/api.service';

const CONFIG_URL = '/assets/config/contact-table-config.json';

function toGridColumnType(col: ContactTableColumnConfig): 'link' | 'actions' | 'text' | 'objectLabel' | undefined {
  if (col.type === 'actions' || col.cellTemplate === 'actionColumnTemplate') return 'actions';
  if (col.type === 'details' || col.cellTemplate === 'viewDetailsTemplate') return 'link';
  return 'text';
}

function mapContactToDisplay(r: ContactRecord): ContactDisplayRecord {
  return {
    id: r.id,
    contactRefNo: {
      label: r.code ?? r.id,
      url: '/contacts/edit/' + r.id,
    },
    name: r.name ?? '',
    dateOfBirth: String(r.dateOfBirth ?? ''),
    gender: String(r.gender ?? ''),
    mobileNumber: String(r.mobileNumber ?? ''),
    emailAddress: String(r.emailAddress ?? ''),
    status: r.status ?? '',
    identityDetails: String(r.identityDetails ?? ''),
    aadhaarNumber: String(r.aadhaarNumber ?? ''),
    panNumber: String(r.panNumber ?? ''),
    maritalStatus: String(r.maritalStatus ?? ''),
  };
}

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.scss'],
})
export class ContactListComponent implements OnInit {
  records: ContactDisplayRecord[] = [];
  displayedColumns: string[] = [];
  mdsRichDataGrid: MdsConfigurableRichDataGrid = { richDataGridConfig: [] };

  dataGridModel: RichDataGridModel = {};
  noRecordsFoundModel = { title: 'No contacts', message: 'No contacts available. Click "Add Contact" to create one.' };

  toolbarButtons: ButtonModel[] = [
    {
      id: 'add',
      label: 'Add Contact',
      type: 'button',
      color: 'primary',
      variant: 'raised',
    },
  ];

  constructor(
    private router: Router,
    private http: HttpClient,
    private apiService: ApiService
  ) {}

  ngOnInit(): void {
    this.http.get<ContactTableConfig>(CONFIG_URL).subscribe({
      next: (config) => this.applyConfig(config),
      error: () => this.applyFallbackConfig(),
    });
  }

  private applyConfig(config: ContactTableConfig): void {
    const columns = (config.columnsConfig ?? [])
      .filter((c) => c.isApplicable !== false)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

    this.displayedColumns = columns.map((c) => c.id);
    this.mdsRichDataGrid = {
      richDataGridConfig: columns.map((c) => {
        const col: RichDataGridColumnConfig = {
          id: c.id,
          columnName: c.columnField ?? c.id,
          customLabel: c.columnName,
          alignment: c.alignment === 'right' ? 'right' : 'left',
          type: toGridColumnType(c),
          cellTemplate: c.cellTemplate,
        };
        if (col.type === 'actions' && c.actions?.length) col.actions = c.actions;
        return col;
      }),
    };
    this.dataGridModel = this.displayedColumns.reduce((acc, id) => ({ ...acc, [id]: {} }), {} as RichDataGridModel);

    this.loadContactRecordsFromApi();
  }

  private applyFallbackConfig(): void {
    this.displayedColumns = [
      'contactRefNo',
      'name',
      'dateOfBirth',
      'gender',
      'mobileNumber',
      'emailAddress',
      'status',
      'identityDetails',
      'aadhaarNumber',
      'panNumber',
      'maritalStatus',
      'actions',
    ];
    this.mdsRichDataGrid = {
      richDataGridConfig: [
        { id: 'contactRefNo', columnName: 'contactRefNo', customLabel: 'Contact Ref No', type: 'link' },
        { id: 'name', columnName: 'name', customLabel: 'Name' },
        { id: 'dateOfBirth', columnName: 'dateOfBirth', customLabel: 'Date of Birth' },
        { id: 'gender', columnName: 'gender', customLabel: 'Gender' },
        { id: 'mobileNumber', columnName: 'mobileNumber', customLabel: 'Mobile Number' },
        { id: 'emailAddress', columnName: 'emailAddress', customLabel: 'Email Address' },
        { id: 'status', columnName: 'status', customLabel: 'Status' },
        { id: 'identityDetails', columnName: 'identityDetails', customLabel: 'Identity Details' },
        { id: 'aadhaarNumber', columnName: 'aadhaarNumber', customLabel: 'Aadhaar Number' },
        { id: 'panNumber', columnName: 'panNumber', customLabel: 'PAN Number' },
        { id: 'maritalStatus', columnName: 'maritalStatus', customLabel: 'Marital Status' },
        { id: 'actions', columnName: 'actions', customLabel: 'Actions', type: 'actions', actions: ['edit', 'delete'] },
      ],
    };
    this.dataGridModel = this.displayedColumns.reduce((acc, id) => ({ ...acc, [id]: {} }), {} as RichDataGridModel);
    this.loadContactRecordsFromApi();
  }

  /** Loads rows from Firebase (`contact.json`). On HTTP error, uses local sample data so the page still works. */
  private loadContactRecordsFromApi(): void {
    this.apiService.getData().subscribe({
      next: (data) => {
        const fromDb = parseFirebaseContactsPayload(data);
        this.records = fromDb.map(mapContactToDisplay);
      },
      error: () => {
        const fallback = CONTACT_CENTER_DATA.data?.records ?? [];
        this.records = fallback.slice(0, 12).map(mapContactToDisplay);
      },
    });
  }

  onLinkClick(url: string): void {
    if (url) this.router.navigateByUrl(url);
  }

  onDataGridAction(event: ActionRecordSelectionState): void {
    const record = this.records.find((r) => r.id === event.recordId);
    if (!record) return;
    if (event.selectedAction === 'edit') {
      this.router.navigate(['/contacts/edit', record.id]);
    } else if (event.selectedAction === 'delete') {
      if (confirm(`Delete contact ${record.name || record.id}?`)) {
        this.apiService.deleteContactData(record.id).subscribe({
          next: () => this.loadContactRecordsFromApi(),
          error: () => {
            this.records = this.records.filter((r) => r.id !== record.id);
          },
        });
      }
    }
  }

  onAdd(): void {
    this.router.navigate(['/contacts/new']);
  }

  onToolbarButtonClick(button: ButtonModel): void {
    if (button.id === 'add') {
      this.onAdd();
    }
  }
}
