import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { PaymentRecord } from '../models/payment-center.model';
import { PaymentTableConfig, PaymentTableColumnConfig, PaymentTableRow } from '../models/payment-table-config.model';
import { PAYMENT_CENTER_DATA } from '../data/payment-center.data';
import {
  MdsConfigurableRichDataGrid,
  RichDataGridModel,
  RichDataGridColumnConfig,
  ActionRecordSelectionState,
} from '../../container/models/rich-data-grid.model';

const CONFIG_URL = '/assets/config/payment-table-config.json';

/** Map config column cellTemplate/type to rich grid column type */
function toGridColumnType(col: PaymentTableColumnConfig): 'link' | 'actions' | 'text' | 'objectLabel' | undefined {
  if (col.type === 'actions' || col.cellTemplate === 'actionColumnTemplate') return 'actions';
  if (col.type === 'details' || col.cellTemplate === 'viewDetailsTemplate') return 'link';
  return 'text';
}

/** Map API PaymentRecord to row keyed by config column id */
function mapPaymentToTableRow(r: PaymentRecord): PaymentTableRow {
  const amountStr =
    r.instructedAmount != null && r.instructedCurrency
      ? `${Number(r.instructedAmount).toLocaleString()} ${r.instructedCurrency}`
      : '';
  const debitAmountStr =
    r.debitAmount != null && r.debitCurrency
      ? `${Number(r.debitAmount).toLocaleString()} ${r.debitCurrency}`
      : r.debitAmount != null
        ? String(r.debitAmount)
        : '';
  return {
    id: {
      label: r.channelSequenceId ?? r.id,
      url: '/payments/' + r.id,
    },
    debtorAccountId: r.debtorAccount?.accountNumber ?? r.debtorAccountId ?? '',
    name: r.creditorInfo?.name ?? '',
    instructedAmount: amountStr,
    valueDate: r.valueDate ?? '',
    status: r.status ?? '',
    rejectReason: r.rejectReason ?? '',
    paymentRail: r.paymentRailInfo?.description ?? r.paymentRail ?? '',
    subproductCode: r.paymentBusinessProduct?.description ?? r.subproductCode ?? '',
    debtorId: r.debtor?.name ?? r.debtorId ?? '',
    debitAmount: debitAmountStr,
    originatorReference: r.originatorReference ?? '',
    createdBy: r.creatorInfo?.login_id ?? r.createdBy ?? '',
    accountId: r.creditorInfo?.accountId ?? '',
    corporateAccountId: r.creditorInfo?.corporateAccountId ?? '',
    createdTs: r.createdTs ?? '',
    channelSequenceId: r.channelSequenceId ?? '',
    creditorId: r.creditorInfo?.creditorId ?? '',
    instructedCurrency: r.instructedCurrency ?? (r as { paymentRailCurrencyInfo?: { currencyCode?: string } }).paymentRailCurrencyInfo?.currencyCode ?? '',
    debitCurrency: r.debitCurrency ?? '',
    accountName: r.creditorInfo?.accountName ?? '',
    taxId: r.taxId ?? '',
  };
}

@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html',
  styleUrls: ['./payment-list.component.scss'],
})
export class PaymentListComponent implements OnInit {
  records: PaymentTableRow[] = [];
  displayedColumns: string[] = [];
  mdsRichDataGrid: MdsConfigurableRichDataGrid = { richDataGridConfig: [] };
  dataGridModel: RichDataGridModel = {};
  noRecordsFoundModel = { title: 'No payments', message: 'No payments available.' };
  pageSize = 25;
  pageSizeOptions: number[] = [10, 25, 50, 100, 200, 500];
  configLoaded = false;

  constructor(
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.http.get<PaymentTableConfig>(CONFIG_URL).subscribe({
      next: (config) => this.applyConfig(config),
      error: () => {
        const apiRecords = PAYMENT_CENTER_DATA.data?.records ?? [];
        this.records = apiRecords.map(mapPaymentToTableRow);
        this.configLoaded = true;
      },
    });
  }

  private applyConfig(config: PaymentTableConfig): void {
    const tableConfig = config.tableConfig;
    if (tableConfig?.defaultPageSize != null) this.pageSize = tableConfig.defaultPageSize;
    if (tableConfig?.pageSizeOptions?.length) this.pageSizeOptions = tableConfig.pageSizeOptions;

    const columns = (config.columnsConfig ?? [])
      .filter((c) => c.isApplicable !== false)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

    this.displayedColumns = columns.map((c) => c.id);
    this.mdsRichDataGrid = {
      richDataGridConfig: columns.map((c) => {
        const col: RichDataGridColumnConfig = {
          id: c.id,
          columnName: c.columnField ?? c.id,
          customLabel: c.columnName,
          alignment: c.alignment === 'right' ? 'right' : 'left',
          type: toGridColumnType(c),
          cellTemplate: c.cellTemplate,
        };
        if (col.type === 'actions' && c.actions?.length) col.actions = c.actions;
        return col;
      }),
    };
    this.dataGridModel = this.displayedColumns.reduce(
      (acc, id) => ({ ...acc, [id]: {} }),
      {} as RichDataGridModel
    );

    const apiRecords = PAYMENT_CENTER_DATA.data?.records ?? [];
    this.records = apiRecords.map(mapPaymentToTableRow);
    this.configLoaded = true;
  }

  onLinkClick(url: string): void {
    if (url) this.router.navigateByUrl(url);
  }

  onCreatePayment(): void {
    this.router.navigate(['/payments/new']);
  }

  onDataGridAction(event: ActionRecordSelectionState): void {
    const recordId = typeof event.recordId === 'string' ? event.recordId : '';
    const record = this.records.find((r) => {
      const id = typeof r.id === 'string' ? r.id : (r.id as { url?: string })?.url ?? '';
      return id === recordId;
    });
    if (!record) return;
    const idLabel = typeof record.id === 'string' ? record.id : (record.id as { label?: string }).label ?? '';
    if (event.selectedAction === 'approve') {
      alert(`Approve payment ${idLabel}`);
    } else if (event.selectedAction === 'reject') {
      if (confirm(`Reject payment ${idLabel}?`)) alert('Payment rejected.');
    }
  }
}
