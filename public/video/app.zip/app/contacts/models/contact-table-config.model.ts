export interface ContactTableColumnConfig {
  id: string;
  order: number;
  columnName: string;
  columnField?: string | null;
  dataPath?: string;
  cellTemplate?: string;
  alignment?: 'left' | 'right';
  type?: string;
  actions?: string[];
  isApplicable?: boolean;
  isSortable?: boolean;
  [key: string]: unknown;
}

export interface ContactTableTableConfig {
  id?: string;
  title?: string;
  defaultPageSize?: number;
  pageSizeOptions?: number[];
  defaultSortColumn?: string;
  defaultSortOrder?: string;
  [key: string]: unknown;
}

export interface ContactTableConfig {
  tableConfig?: ContactTableTableConfig;
  columnsConfig: ContactTableColumnConfig[];
  filterConfig?: unknown;
  controlBarConfig?: unknown;
}
