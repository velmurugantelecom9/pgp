import { Component, Input } from '@angular/core';

@Component({
  selector: 'lib-status-template',
  templateUrl: './status-template.component.html',
  styleUrls: ['./status-template.component.scss'],
})
export class LibStatusTemplateComponent {
  /** Status value to display (e.g. APPROVED, PENDING_REQUEST, REJECTED) */
  @Input() value: string | null = '';

  /** CSS class based on status */
  get statusClass(): string {
    const v = (this.value || '').toUpperCase();
    if (v === 'APPROVED') return 'status-approved';
    if (v === 'PENDING_REQUEST') return 'status-pending';
    if (v === 'REJECTED') return 'status-rejected';
    return '';
  }
}
