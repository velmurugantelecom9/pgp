/** Single column config from payment-table-config.json columnsConfig */
export interface PaymentTableColumnConfig {
  id: string;
  order: number;
  columnName: string;
  columnField?: string | null;
  dataPath?: string;
  cellTemplate?: string;
  alignment?: 'left' | 'right';
  type?: string;
  actions?: string[];
  isApplicable?: boolean;
  isSortable?: boolean;
  [key: string]: unknown;
}

/** tableConfig section */
export interface PaymentTableTableConfig {
  id?: string;
  title?: string;
  defaultPageSize?: number;
  pageSizeOptions?: number[];
  defaultSortColumn?: string;
  defaultSortOrder?: string;
  [key: string]: unknown;
}

/** Root payment table config (payment-table-config.json) */
export interface PaymentTableConfig {
  tableConfig?: PaymentTableTableConfig;
  filterConfig?: unknown;
  columnsConfig: PaymentTableColumnConfig[];
  controlBarConfig?: unknown;
}

/** Row shape keyed by config column id for the grid */
export interface PaymentTableRow {
  id: string | { label: string; url: string };
  [key: string]: unknown;
}
