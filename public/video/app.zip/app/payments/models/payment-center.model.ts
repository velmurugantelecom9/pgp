/** Tag for debit account (currency, country, entity) */
export interface PaymentTag {
  label: string;
  type: string;
}

/** Debit account with label and tags */
export interface DebitAccountNumber {
  label: string;
  tags?: PaymentTag[];
}

/** Navigation link (e.g. Payment Ref No) */
export interface PaymentNavigation {
  type: string;
  label: string;
  url: string;
}

/** Action button in row */
export interface PaymentActionButton {
  buttonAction: string;
  buttonName: string;
}

/** Amount with currency */
export interface PaymentAmount {
  value: number;
  currencyCode: string;
  label?: string;
  timestamp?: string;
}

/** Single payment record (index signature for GenericRow compatibility in lib-rich-data-grid) */
export interface PaymentCenterRecord {
  id: string;
  isFavouriteSelected?: boolean;
  referenceAccount: string;
  payToAccount: string;
  beneficiaryName: string;
  valueDate: string;
  debitAccountNumber: DebitAccountNumber;
  paymentType: string;
  status: string;
  paymentAmount: string;
  PaymentRefNo: PaymentNavigation;
  actionButtons: PaymentActionButton[];
  bank: string;
  latestActivity: string;
  ledgerBalance?: PaymentAmount;
  availableBalance?: PaymentAmount;
  availableBalanceUSD?: PaymentAmount;
  [key: string]: unknown;
}

/** Group in payment center */
export interface PaymentCenterGroup {
  groupName: string;
  groupAmount: PaymentAmount;
  groupReferenceAmount: PaymentAmount;
  groupIdentifier: string;
  groupCount: number;
  records: PaymentCenterRecord[];
}

/** Top-level payment center response (grouped) */
export interface PaymentCenterResponse {
  paymentCenter: PaymentCenterGroup[];
}

/** Flat payment center – array of records only */
export interface PaymentCenterFlatResponse {
  paymentCenter: PaymentCenterRecord[];
}

/** API payment record (data.records[] from API) */
export interface PaymentCreditorInfo {
  creditorId?: string | null;
  name?: string | null;
  accountId?: string | null;
  corporateAccountId?: string | null;
  accountName?: string | null;
  accountNumber?: string | null;
  alias?: string | null;
  __typename?: string;
}

export interface PaymentDebtor {
  name?: string;
  __typename?: string;
}

export interface PaymentDebtorAccount {
  name?: string;
  alias?: string;
  accountNumber?: string;
  __typename?: string;
}

export interface PaymentRailInfo {
  description?: string;
  __typename?: string;
}

export interface PaymentBusinessProduct {
  description?: string;
  __typename?: string;
}

export interface PaymentCreatorInfo {
  first_name?: string;
  last_name?: string;
  mobile_number?: string;
  email_id?: string;
  login_id?: string;
  __typename?: string;
}

export interface PaymentRecord {
  id: string;
  nextActions?: string;
  channelSequenceId?: string;
  originatorReference?: string;
  debtorId?: string;
  valueDate?: string;
  paymentRail?: string;
  createdBy?: string;
  createdTs?: string;
  instructedAmount?: number;
  instructedCurrency?: string;
  debitAmount?: number;
  debitCurrency?: string;
  debtorAccountId?: string;
  taxId?: string | null;
  creditorInfo?: PaymentCreditorInfo | null;
  rejectReason?: string | null;
  subproductCode?: string;
  status?: string;
  debtor?: PaymentDebtor | null;
  creditorAccount?: unknown;
  corporateAccount?: unknown;
  paymentRailInfo?: PaymentRailInfo | null;
  paymentBusinessProduct?: PaymentBusinessProduct | null;
  creatorInfo?: PaymentCreatorInfo | null;
  paymentRailCurrencyInfo?: { name?: string | null; __typename?: string } | null;
  debtorAccount?: PaymentDebtorAccount | null;
  __typename?: string;
  [key: string]: unknown;
}

/** API response: { data: { count: [...], records: [...] } } */
export interface PaymentDataResponse {
  data: {
    count?: Array<{ total?: number; __typename?: string }>;
    records: PaymentRecord[];
  };
}
