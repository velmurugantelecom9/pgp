/** Subset of middleware DynamicFormConfig used by local dds-fabric-form. */
export interface FabricFormOption {
  label: string;
  value: string;
}

export interface FabricFormField {
  controlType: string;
  fieldID: string;
  fieldLabel?: string;
  ariaLabel?: string;
  dataSourceKey?: string;
  mandatory?: boolean;
  hideOnLoad?: boolean;
  placeholder?: string;
  options?: FabricFormOption[];
  value?: unknown;
  multiple?: boolean;
  validators?: Array<{
    validatorName?: string;
    validatorValue?: string;
    errorMessage?: string;
    isTranslationRequired?: boolean;
  }>;
  rules?: Array<{
    when?: {
      field: string;
      op: string;
      value: unknown;
    };
    then?: Array<{
      action: string;
      target?: {
        fields?: string[];
      };
    }>;
  }>;
}

export interface FabricFormSection {
  sectionID: string;
  sectionLabel?: string;
  /** When true, entire section is hidden (IGTB parity). */
  hideOnLoad?: boolean;
  formFieldConfig?: FabricFormField[];
}

export interface FabricFormMeta {
  formConfig?: Partial<{
    formTitle: string;
    submitCreateLabel: string;
    submitUpdateLabel: string;
    cancelLabel: string;
  }> &
    Record<string, unknown>;
  formSectionConfig?: FabricFormSection[];
}

/** Value passed to `dds-fabric-form` — full JSON object or the sections array only. */
export type FabricFormMetaInput = FabricFormMeta | FabricFormSection[] | null;
