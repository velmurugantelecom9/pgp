import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import type { FabricFormMeta, FabricFormOption } from '../models/fabric-form.model';

/**
 * Loads JSON form metadata and dropdown option maps (same role as IGTB Cbx*FormLoaderService).
 * Use for contact, payment, and any JSON-driven screen.
 */
@Injectable({ providedIn: 'root' })
export class FormJsonLoaderService {
  constructor(private http: HttpClient) {}

  /** GET form config JSON (formConfig + formSectionConfig + …). */
  loadFormMetaData(url: string): Observable<FabricFormMeta> {
    return this.http.get<FabricFormMeta>(url);
  }

  /** GET map of dataSourceKey → { label, value }[]. */
  loadDropdownData(url: string): Observable<Record<string, FabricFormOption[]>> {
    return this.http.get<Record<string, Array<string | FabricFormOption>>>(url).pipe(
      map((data) => {
        const out: Record<string, FabricFormOption[]> = {};
        Object.keys(data || {}).forEach((key) => {
          out[key] = this.normalizeOptions(data[key]);
        });
        return out;
      })
    );
  }

  /** Optional transform hook — mirror IGTB `formLoaderService.transform()`. */
  transform<T extends FabricFormMeta>(raw: T): T {
    return raw;
  }

  private normalizeOptions(options: Array<string | FabricFormOption> | undefined): FabricFormOption[] {
    if (!options?.length) {
      return [];
    }
    return options.map((item) =>
      typeof item === 'string' ? { label: item, value: item } : { label: item.label, value: item.value }
    );
  }
}
