/**
 * Generic key-value object for locales or other metadata.
 */
export interface GenericObject {
  [key: string]: string | undefined;
}

/**
 * Model for a single button passed to the shared button component.
 * Supports both `name` (sample API) and `label` (backward compatibility).
 */
export interface ButtonModel {
  id: string;
  /** Display text (use `label` as alias if preferred) */
  name?: string;
  label?: string;
  title?: string;
  /** CSS class(es) applied to the button, e.g. 'btn-primary' */
  class?: string;
  iconName?: string;
  count?: number;
  type?: 'button' | 'submit';
  color?: 'primary' | 'accent' | 'warn' | '';
  variant?: 'raised' | 'flat';
  [key: string]: unknown;
}
